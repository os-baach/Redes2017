#! /usr/bin/env python
# -*- coding: utf-8 -*-


class MyApiServer:
    def __init__(self, my_port = None):
        #TODO
class FunctionWrapper:
    def __init__(self):
        #TODO

     """ **************************************************
    Procedimiento que ofrece nuestro servidor, este metodo sera llamado
    por el cliente con el que estamos hablando, debe de
    hacer lo necesario para mostrar el texto en nuestra pantalla.
    ************************************************** """
    def sendMessage_wrapper(self, message):
        #TODO



